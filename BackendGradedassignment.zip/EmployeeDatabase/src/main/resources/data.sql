insert into Employee values(1,'Rajesh','Sharma','rs@company.com','Hr');
insert into Employee values(2,'Shivkumar','Mishra','sm@company.com','IT-dept');

insert into Employee values(3,'Hitesh','Deshmukh','hd@company.com','Developer');
insert into Employee values(4,'Kirti','shetty','ks@company.com','Hr');

insert into Employee values(5,'Amruta','Kulkarni','ak@company.com','BDA');
insert into Employee values(6,'Subodh','Arora','sa@company.com','Analyst');

